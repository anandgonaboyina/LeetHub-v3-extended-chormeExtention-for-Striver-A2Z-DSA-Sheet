let api = isChrome() ? chrome : isFirefox() ? browser : undefined;

// const ONE_HOUR_MS = 60 * 60 * 1000;

api.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install') {
    // Allow persistent stats to sync on repo link
    api.storage.local.set({ sync_stats: true});
  }
});

api.runtime.onMessage.addListener(handleMessage);

const GITHUB_CLIENT_ID = '0114dd35b156d4729fac';
const GITHUB_CLIENT_SECRET = 'cfc3301d9745530bf1b31e92528ad9c31fd3f995';

let isExchangingOAuth = false;

async function exchangeOAuthCode(code, tabId) {
  if (!code || isExchangingOAuth) return;
  isExchangingOAuth = true;

  try {
    // Request OAuth access token directly from GitHub
    const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        client_id: GITHUB_CLIENT_ID,
        client_secret: GITHUB_CLIENT_SECRET,
        code: code
      })
    });

    const tokenData = await tokenRes.json();
    if (!tokenData || !tokenData.access_token) {
      console.error('Failed to get GitHub access token:', tokenData);
      isExchangingOAuth = false;
      return;
    }

    const token = tokenData.access_token;

    // Fetch user profile from GitHub API
    const userRes = await fetch('https://api.github.com/user', {
      headers: {
        Authorization: `token ${token}`,
        Accept: 'application/vnd.github.v3+json'
      }
    });

    let username = '';
    if (userRes.ok) {
      const userData = await userRes.json();
      username = userData.login || '';
    }

    await api.storage.local.set({
      leethub_token: token,
      leethub_username: username,
      pipe_leethub: false
    });

    // Close the GitHub auth tab
    if (tabId) {
      try { api.tabs.remove(tabId); } catch (e) {}
    } else {
      api.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        if (tabs && tabs[0]) {
          try { api.tabs.remove(tabs[0].id); } catch (e) {}
        }
      });
    }

    // Open onboarding welcome page to create/link repository
    const urlOnboarding = api.runtime.getURL('welcome.html');
    api.tabs.create({ url: urlOnboarding, active: true });
  } catch (err) {
    console.error('Error during GitHub OAuth exchange:', err);
  } finally {
    isExchangingOAuth = false;
  }
}

function checkAndExchangeNavUrl(url, tabId) {
  if (!url || !url.includes('github.com')) return;
  try {
    const parsed = new URL(url);
    const code = parsed.searchParams.get('code');
    if (code) {
      exchangeOAuthCode(code, tabId);
    }
  } catch (e) {
    const match = url.match(/[?&]code=([\w\/\-]+)/);
    if (match && match[1]) {
      exchangeOAuthCode(match[1], tabId);
    }
  }
}

// Automatically intercept GitHub OAuth redirect before page load
if (api.webNavigation) {
  if (api.webNavigation.onBeforeNavigate) {
    api.webNavigation.onBeforeNavigate.addListener((details) => {
      checkAndExchangeNavUrl(details.url, details.tabId);
    }, { url: [{ hostSuffix: 'github.com' }] });
  }
  if (api.webNavigation.onCommitted) {
    api.webNavigation.onCommitted.addListener((details) => {
      checkAndExchangeNavUrl(details.url, details.tabId);
    }, { url: [{ hostSuffix: 'github.com' }] });
  }
}

function handleMessage(request, sender, sendResponse) {
  if (request && request.type === 'GITHUB_AUTH_CODE') {
    const tabId = (sender && sender.tab && sender.tab.id) || null;
    exchangeOAuthCode(request.code, tabId);
    return true;
  } else if (request && request.closeWebPage === true && request.isSuccess === true) {
    /* Set username */
    api.storage.local.set({ leethub_username: request.username });

    /* Set token */
    api.storage.local.set({ leethub_token: request.token });

    /* Close pipe */
    api.storage.local.set({ pipe_leethub: false });

    const tabId = (sender && sender.tab && sender.tab.id) || null;
    if (tabId) {
      try { api.tabs.remove(tabId); } catch (e) {}
    } else {
      api.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        if (tabs && tabs[0]) api.tabs.remove(tabs[0].id);
      });
    }

    /* Go to onboarding for UX */
    const urlOnboarding = api.runtime.getURL('welcome.html');
    api.tabs.create({ url: urlOnboarding, active: true });
  } else if (request && request.closeWebPage === true && request.isSuccess === false) {
    console.error('Authentication attempt unsuccessful.');
    const tabId = (sender && sender.tab && sender.tab.id) || null;
    if (tabId) {
      try { api.tabs.remove(tabId); } catch (e) {}
    } else {
      api.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        if (tabs && tabs[0]) api.tabs.remove(tabs[0].id);
      });
    }
  } else if (request.type === 'LEETCODE_SUBMISSION') {
    api.webNavigation.onHistoryStateUpdated.addListener(
      (e = function (details) {
        const match = details.url.match(/\/submissions\/(?:detail\/)?(\d+)/);
        if (match) {
          const submissionId = match[1];
          sendResponse({ submissionId });
          api.webNavigation.onHistoryStateUpdated.removeListener(e);
        }
      }),
      { url: [{ hostSuffix: 'leetcode.com' }, { pathContains: 'submissions' }] }
    );
  } else if (request && request.isStriver === true) {
    // ========================================================================
    // STRIVER A2Z HANDLER — Category-based saves, README question, full repo scan
    // ========================================================================
    (async () => {
      try {
        const { leethub_token, leethub_hook } = await api.storage.local.get(['leethub_token', 'leethub_hook']);
        if (!leethub_token || !leethub_hook) {
          sendResponse({ success: false, error: 'Not authenticated or no repo linked. Open the LeetHub popup to set up.' });
          return;
        }

        const STRIVER_ROOT = '0000-Strivers-A2Z-DSA-Sheet';
        const METADATA_PATH = `${STRIVER_ROOT}/.metadata.json`;

        // --- Shared helpers ---------------------------------------------------

        const b64Encode = (str) => {
          return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode('0x' + p1)));
        };

        const b64Decode = (data) => decodeURIComponent(escape(atob(data)));

        const sanitizeName = (name) => {
          if (!name) return 'Problem';
          return name.replace(/[^a-zA-Z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
        };

        const stripProblemNumber = (str) => {
          if (!str) return '';
          return str.replace(/^\s*\d+[\.\-\:\s_]+\s*/, '').trim();
        };

        const normalizeSlug = (str) => {
          if (!str) return '';
          return str
            .toLowerCase()
            .replace(/^\s*\d+[\.\-\:\s_]+/, '')
            .replace(/[^a-z0-9]/g, '');
        };

        const slugToTitle = (slug) => {
          if (!slug) return 'Unknown Problem';
          const clean = stripProblemNumber(slug);
          return clean
            .replace(/-/g, ' ')
            .replace(/\b\w/g, (char) => char.toUpperCase());
        };

        const langExtMap = {
          'cpp': '.cpp', 'c++': '.cpp', 'java': '.java', 'python': '.py',
          'py': '.py', 'python3': '.py', 'javascript': '.js', 'js': '.js',
          'c': '.c', 'csharp': '.cs', 'cs': '.cs', 'typescript': '.ts',
          'ts': '.ts', 'go': '.go', 'rust': '.rs', 'rs': '.rs',
          'dart': '.dart', 'kotlin': '.kt', 'swift': '.swift', 'ruby': '.rb',
          'scala': '.scala', 'php': '.php'
        };

        const codeExtensions = new Set(Object.values(langExtMap));

        const ghHeaders = {
          Authorization: `token ${leethub_token}`,
          Accept: 'application/vnd.github.v3+json'
        };

        /** GET a file from GitHub. Returns {content, sha} or null. */
        const ghGet = async (filePath) => {
          const url = `https://api.github.com/repos/${leethub_hook}/contents/${filePath}`;
          try {
            const res = await fetch(url, { headers: ghHeaders });
            if (res.status === 200) {
              const data = await res.json();
              return { content: b64Decode(data.content), sha: data.sha };
            }
          } catch (e) { /* file doesn't exist */ }
          return null;
        };

        /** PUT (create or update) a file on GitHub. */
        const ghPut = async (filePath, content, commitMsg) => {
          const url = `https://api.github.com/repos/${leethub_hook}/contents/${filePath}`;
          let sha = null;
          try {
            const res = await fetch(url, { headers: ghHeaders });
            if (res.status === 200) {
              const data = await res.json();
              sha = data.sha;
            }
          } catch (e) {}
          const body = { message: commitMsg, content: b64Encode(content) };
          if (sha) body.sha = sha;
          const putRes = await fetch(url, {
            method: 'PUT',
            headers: { ...ghHeaders, 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
          });
          if (!putRes.ok) {
            const errBody = await putRes.text();
            throw new Error(`GitHub API ${putRes.status}: ${errBody}`);
          }
          return putRes;
        };

        /** DELETE a single file on GitHub. */
        const ghDelete = async (filePath, sha, commitMsg) => {
          const url = `https://api.github.com/repos/${leethub_hook}/contents/${filePath}`;
          let fileSha = sha;
          if (!fileSha) {
            try {
              const getRes = await fetch(url, { headers: ghHeaders });
              if (getRes.ok) {
                const data = await getRes.json();
                fileSha = data.sha;
              }
            } catch (e) {}
          }
          if (!fileSha) return;

          try {
            await fetch(url, {
              method: 'DELETE',
              headers: { ...ghHeaders, 'Content-Type': 'application/json' },
              body: JSON.stringify({ message: commitMsg || `Delete ${filePath}`, sha: fileSha })
            });
          } catch (e) {
            console.error(`Failed to delete ${filePath}:`, e);
          }
        };

        /** DELETE all files inside a folder on GitHub. */
        const ghDeleteFolder = async (folderPath) => {
          try {
            const res = await fetch(`https://api.github.com/repos/${leethub_hook}/contents/${folderPath}`, { headers: ghHeaders });
            if (res.ok) {
              const items = await res.json();
              if (Array.isArray(items)) {
                for (const item of items) {
                  if (item.type === 'file') {
                    await ghDelete(item.path, item.sha, `Clean up old location: ${item.path}`);
                  }
                }
              }
            }
          } catch (e) {}
        };

        /** Fetch default repository branch. */
        const getDefaultBranch = async () => {
          try {
            const repoRes = await fetch(`https://api.github.com/repos/${leethub_hook}`, { headers: ghHeaders });
            if (repoRes.ok) {
              const repoData = await repoRes.json();
              return repoData.default_branch || 'main';
            }
          } catch (e) {}
          return 'main';
        };

        /** Fetch entire Git Tree recursively for full repo visibility. */
        const ghGetTree = async (branch = 'main') => {
          try {
            const treeRes = await fetch(
              `https://api.github.com/repos/${leethub_hook}/git/trees/${branch}?recursive=1`,
              { headers: ghHeaders }
            );
            if (treeRes.ok) {
              const data = await treeRes.json();
              return data.tree || [];
            }
          } catch (e) {}
          return [];
        };

        // --- Read / Write metadata --------------------------------------------

        const getMetadata = async () => {
          const file = await ghGet(METADATA_PATH);
          if (file) {
            try { return JSON.parse(file.content); } catch (e) {}
          }
          return { problems: {} };
        };

        const saveMetadata = async (metadata) => {
          await ghPut(METADATA_PATH, JSON.stringify(metadata, null, 2), 'Update Striver A2Z metadata');
        };

        // --- Master Repository Problem Scanner --------------------------------
        // Scans the ENTIRE repository folder (0000-Strivers-A2Z-DSA-Sheet)
        // and merges with .metadata.json so ALL historical & current problems appear.
        const getAllRepoProblems = async () => {
          const defaultBranch = await getDefaultBranch();
          const [treeItems, metadata] = await Promise.all([
            ghGetTree(defaultBranch),
            getMetadata()
          ]);

          const problemsMap = new Map(); // key: problemSlug or normalized path
          const categoriesSet = new Set();

          // 1. First, index everything from git tree
          const striverFiles = treeItems.filter(item =>
            item.path.startsWith(`${STRIVER_ROOT}/`) &&
            item.type === 'blob' &&
            item.path !== `${STRIVER_ROOT}/README.md` &&
            item.path !== METADATA_PATH
          );

          for (const item of striverFiles) {
            const relPath = item.path.substring(STRIVER_ROOT.length + 1); // e.g. Arrays/Two-Sum/Two-Sum.cpp
            const parts = relPath.split('/');

            // Skip README files inside folders when identifying solutions, but record folder
            const fileName = parts[parts.length - 1];
            const ext = '.' + fileName.split('.').pop();
            const isCodeFile = codeExtensions.has(ext);

            if (!isCodeFile) continue;

            let category = 'General';
            let subcategory = '';
            let problemSlug = '';
            let folderPath = '';

            if (parts.length === 2) {
              // 0000-Strivers-A2Z-DSA-Sheet/Two-Sum/solution.cpp OR Arrays/Two-Sum.cpp
              if (parts[1].startsWith('solution.') || isCodeFile) {
                problemSlug = parts[0];
                folderPath = `${STRIVER_ROOT}/${parts[0]}`;
              } else {
                category = parts[0];
                problemSlug = parts[1].replace(/\.[^.]+$/, '');
                folderPath = `${STRIVER_ROOT}/${parts[0]}`;
              }
            } else if (parts.length === 3) {
              // 0000-Strivers-A2Z-DSA-Sheet/Arrays/Two-Sum/solution.cpp OR Arrays/Two-Sum/Two-Sum.cpp
              category = parts[0];
              problemSlug = parts[1];
              folderPath = `${STRIVER_ROOT}/${parts[0]}/${parts[1]}`;
            } else if (parts.length >= 4) {
              // 0000-Strivers-A2Z-DSA-Sheet/DP/1D/Frog-Jump/solution.cpp
              category = parts[0];
              subcategory = parts[1];
              problemSlug = parts[2];
              folderPath = `${STRIVER_ROOT}/${parts[0]}/${parts[1]}/${parts[2]}`;
            }

            if (category) categoriesSet.add(category);

            const cleanSlug = stripProblemNumber(problemSlug) || problemSlug;
            const normKey = normalizeSlug(problemSlug) || cleanSlug.toLowerCase();
            problemsMap.set(normKey, {
              problemSlug: cleanSlug,
              problemName: slugToTitle(cleanSlug),
              category,
              subcategory,
              language: ext.replace('.', ''),
              githubPath: item.path,
              folderPath: folderPath || `${STRIVER_ROOT}/${cleanSlug}`,
              githubUrl: `https://github.com/${leethub_hook}/blob/${defaultBranch}/${item.path}`,
              lastUpdated: null,
              url: '',
              sha: item.sha
            });
          }

          // 2. Merge with rich metadata (takes precedence for title, url, timestamp)
          if (metadata && metadata.problems) {
            for (const mKey in metadata.problems) {
              const meta = metadata.problems[mKey];
              const safeSlug = sanitizeName(meta.problemName).toLowerCase();
              const existing = problemsMap.get(safeSlug);

              if (meta.category) categoriesSet.add(meta.category);

              if (existing) {
                existing.problemName = meta.problemName || existing.problemName;
                existing.category = meta.category || existing.category;
                existing.subcategory = meta.subcategory || existing.subcategory;
                existing.language = meta.language || existing.language;
                existing.url = meta.url || existing.url;
                existing.lastUpdated = meta.lastUpdated || existing.lastUpdated;
                if (meta.githubPath) {
                  existing.githubPath = meta.githubPath;
                  existing.githubUrl = `https://github.com/${leethub_hook}/blob/${defaultBranch}/${meta.githubPath}`;
                }
              } else {
                // If in metadata but not in git tree (or tree had branch delay)
                problemsMap.set(safeSlug, {
                  problemSlug: sanitizeName(meta.problemName),
                  problemName: meta.problemName,
                  category: meta.category || 'General',
                  subcategory: meta.subcategory || '',
                  language: meta.language || 'cpp',
                  githubPath: meta.githubPath || '',
                  folderPath: meta.githubPath ? meta.githubPath.substring(0, meta.githubPath.lastIndexOf('/')) : `${STRIVER_ROOT}/${sanitizeName(meta.problemName)}`,
                  githubUrl: meta.githubPath ? `https://github.com/${leethub_hook}/blob/${defaultBranch}/${meta.githubPath}` : '',
                  lastUpdated: meta.lastUpdated || new Date().toISOString(),
                  url: meta.url || '',
                  sha: null
                });
              }
            }
          }

          const problemsList = Array.from(problemsMap.values());
          // Sort newest first
          problemsList.sort((a, b) => {
            if (a.lastUpdated && b.lastUpdated) {
              return new Date(b.lastUpdated) - new Date(a.lastUpdated);
            }
            if (a.lastUpdated) return -1;
            if (b.lastUpdated) return 1;
            return a.problemName.localeCompare(b.problemName);
          });

          return {
            problems: problemsList,
            categories: Array.from(categoriesSet).filter(Boolean).sort(),
            hook: leethub_hook,
            branch: defaultBranch
          };
        };

        // --- Action Router ----------------------------------------------------

        const action = request.action || 'striver_save';

        // ===== ACTION: striver_check_existing =================================
        // Checks if problem exists BEFORE opening/submitting the form to prefill category & avoid duplicates
        if (action === 'striver_check_existing') {
          const reqTitle = (request.title || '').trim();
          const reqUrl = (request.url || '').trim();
          const reqNorm = normalizeSlug(reqTitle);
          const reqClean = stripProblemNumber(reqTitle).toLowerCase();

          const { problems, categories, hook, branch } = await getAllRepoProblems();

          let found = null;

          // Check by URL exact match first
          if (reqUrl) {
            found = problems.find(p => p.url && p.url.split('?')[0].replace(/\/+$/, '') === reqUrl.split('?')[0].replace(/\/+$/, ''));
          }

          // Check by normalized title or slug (matches with or without numbers, e.g. "745. Check..." vs "Check...")
          if (!found && reqTitle) {
            found = problems.find(p =>
              (reqNorm && normalizeSlug(p.problemSlug) === reqNorm) ||
              (reqNorm && normalizeSlug(p.problemName) === reqNorm) ||
              p.problemSlug.toLowerCase() === reqClean ||
              p.problemName.toLowerCase() === reqClean ||
              p.problemName.toLowerCase() === reqTitle.toLowerCase()
            );
          }

          if (found) {
            sendResponse({
              success: true,
              exists: true,
              problem: found,
              categories,
              hook,
              branch
            });
          } else {
            sendResponse({
              success: true,
              exists: false,
              categories,
              hook,
              branch
            });
          }

        // ===== ACTION: striver_get_categories =================================
        } else if (action === 'striver_get_categories') {
          const { categories } = await getAllRepoProblems();
          sendResponse({ success: true, categories });

        // ===== ACTION: striver_save ===========================================
        } else if (action === 'striver_save') {
          const title = request.title || 'Unknown-Problem';
          const rawCode = request.code || '';
          const lang = (request.language || 'cpp').toLowerCase();
          const category = request.category || '';
          const subcategory = request.subcategory || '';
          const problemUrl = request.url || '';
          const statement = request.statement || '';
          const examples = request.examples || '';
          const difficulty = request.difficulty || 'Medium';

          const oldFolderPath = request.oldFolderPath || null;
          const oldGithubPath = request.oldGithubPath || null;

          if (!rawCode.trim()) {
            sendResponse({ success: false, error: 'Code cannot be empty.' });
            return;
          }
          if (!category.trim()) {
            sendResponse({ success: false, error: 'Category is required.' });
            return;
          }

          const ext = langExtMap[lang] || '.cpp';
          // Ensure folder and problem name have NO leading numbers (matches user's historical folder convention)
          const cleanTitle = stripProblemNumber(title) || title.trim();
          const safeTitle = sanitizeName(cleanTitle);
          const safeCat = sanitizeName(category);
          const safeSubcat = subcategory.trim() ? sanitizeName(subcategory) : '';

          // Target folder: 0000-Strivers-A2Z-DSA-Sheet/Category/[Subcategory/]safeTitle
          let newFolderPath = `${STRIVER_ROOT}/${safeCat}`;
          if (safeSubcat) newFolderPath += `/${safeSubcat}`;
          newFolderPath += `/${safeTitle}`;

          // File name is always solution.ext (e.g. solution.cpp, solution.py, etc.)
          const solutionFileName = `solution${ext}`;
          const solutionPath = `${newFolderPath}/${solutionFileName}`;
          const readmePath = `${newFolderPath}/README.md`;

          const isUpdate = !!(oldFolderPath || oldGithubPath);

          // 1. Clean up old location if category/subcategory changed
          if (oldFolderPath && oldFolderPath !== newFolderPath) {
            await ghDeleteFolder(oldFolderPath);
            if (oldGithubPath && !oldGithubPath.startsWith(oldFolderPath)) {
              await ghDelete(oldGithubPath, null, `Remove old solution ${oldGithubPath}`);
            }
          } else if (oldGithubPath && oldGithubPath !== solutionPath) {
            // Same folder, but old file had a different name (e.g. Problem-Name.cpp -> solution.cpp)
            await ghDelete(oldGithubPath, null, `Replace old solution file with ${solutionFileName}`);
          }

          // 2. Upload Question README.md
          let fullReadme = `<h2><a href="${problemUrl || 'https://takeuforward.org/'}">${title}</a></h2><h3>${difficulty}</h3><hr>`;
          if (statement) {
            fullReadme += `\n${statement}\n`;
          }
          if (examples) {
            fullReadme += `<br><br>\n${examples}\n`;
          }
          if (!statement && !examples) {
            fullReadme += `<p>Problem statement from <a href="${problemUrl || 'https://takeuforward.org/'}">${title}</a> on TakeUForward.</p>`;
          }

          await ghPut(readmePath, fullReadme, `${isUpdate ? 'Update' : 'Add'} README for ${title}`);

          // 3. Upload solution code file
          await ghPut(solutionPath, rawCode, `${isUpdate ? 'Update' : 'Add'} solution for ${title} [${category}]`);

          // 4. Update master README.md table
          const masterReadmePath = `${STRIVER_ROOT}/README.md`;
          const masterFile = await ghGet(masterReadmePath);
          let masterContent = '';
          if (masterFile) {
            masterContent = masterFile.content;
          }
          if (!masterContent.includes('Strivers A2Z DSA Sheet Solutions')) {
            masterContent = '# Strivers A2Z DSA Sheet Solutions\n\n| Problem | Category | Solution |\n| :--- | :--- | :--- |\n';
          }

          const catLabel = safeSubcat ? `${category}/${subcategory}` : category;
          const relativeSolPath = solutionPath.replace(STRIVER_ROOT + '/', '');
          const newRow = `| [${title}](${problemUrl || '#'}) | ${catLabel} | [${solutionFileName}](${relativeSolPath}) |\n`;

          // Replace row if already exists, else append
          const escapedTitle = title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const rowRegex = new RegExp(`\\|\\s*\\[${escapedTitle}\\]\\([^)]*\\)[^\\n]*\\n`, 'g');
          if (masterContent.match(rowRegex)) {
            masterContent = masterContent.replace(rowRegex, newRow);
          } else {
            masterContent += newRow;
          }
          await ghPut(masterReadmePath, masterContent, `Update Master README with ${title}`);

          // 5. Update .metadata.json
          const metadata = await getMetadata();
          const problemKey = problemUrl || safeTitle;

          // If old key was different, clean it up
          if (request.oldKey && request.oldKey !== problemKey && metadata.problems[request.oldKey]) {
            delete metadata.problems[request.oldKey];
          }

          metadata.problems[problemKey] = {
            problemName: cleanTitle,
            category: category,
            subcategory: subcategory || '',
            language: lang,
            extension: ext,
            githubPath: solutionPath,
            folderPath: newFolderPath,
            url: problemUrl,
            lastUpdated: new Date().toISOString()
          };
          await saveMetadata(metadata);

          sendResponse({
            success: true,
            message: `Successfully ${isUpdate ? 'updated' : 'saved'} "${title}" in ${catLabel}!`
          });

        // ===== ACTION: striver_get_code =======================================
        } else if (action === 'striver_get_code') {
          const searchUrl = request.url || '';
          const searchTitle = request.title || '';
          const { problems } = await getAllRepoProblems();

          let found = null;
          if (searchUrl) {
            found = problems.find(p => p.url && p.url.split('?')[0].replace(/\/+$/, '') === searchUrl.split('?')[0].replace(/\/+$/, ''));
          }
          if (!found && searchTitle) {
            const safe = sanitizeName(searchTitle).toLowerCase();
            found = problems.find(p =>
              p.problemSlug.toLowerCase() === safe ||
              sanitizeName(p.problemName).toLowerCase() === safe ||
              p.problemName.toLowerCase() === searchTitle.toLowerCase()
            );
          }

          if (!found || !found.githubPath) {
            sendResponse({ success: false, notFound: true, error: 'Problem not solved yet.' });
            return;
          }

          const codeFile = await ghGet(found.githubPath);
          if (!codeFile) {
            sendResponse({ success: false, error: 'Code file not found in repository.' });
            return;
          }

          sendResponse({
            success: true,
            problemName: found.problemName,
            category: found.category,
            subcategory: found.subcategory,
            language: found.language,
            filePath: found.githubPath,
            lastUpdated: found.lastUpdated,
            code: codeFile.content
          });

        // ===== ACTION: striver_get_all_problems / striver_get_all_metadata =====
        } else if (action === 'striver_get_all_problems' || action === 'striver_get_all_metadata') {
          const { problems, categories, hook, branch } = await getAllRepoProblems();
          sendResponse({
            success: true,
            problems,
            categories,
            hook,
            branch
          });

        // ===== ACTION: striver_get_problem_details ============================
        // Fetches both Question (README.md) and Solution (code) for a problem
        } else if (action === 'striver_get_problem_details') {
          let githubPath = request.githubPath || '';
          let folderPath = request.folderPath || '';
          const problemName = request.problemName || request.title || '';
          const defaultBranch = await getDefaultBranch();

          if (!githubPath || !folderPath) {
            const { problems } = await getAllRepoProblems();
            let found = null;
            if (request.url) {
              found = problems.find(p => p.url && p.url.split('?')[0].replace(/\/+$/, '') === request.url.split('?')[0].replace(/\/+$/, ''));
            }
            if (!found && problemName) {
              const safe = sanitizeName(problemName).toLowerCase();
              found = problems.find(p =>
                p.problemSlug.toLowerCase() === safe ||
                sanitizeName(p.problemName).toLowerCase() === safe ||
                p.problemName.toLowerCase() === problemName.toLowerCase()
              );
            }
            if (found) {
              githubPath = githubPath || found.githubPath;
              folderPath = folderPath || found.folderPath;
            }
          }

          let code = '';
          let readme = '';

          // 1. Fetch solution code
          if (githubPath) {
            const codeFile = await ghGet(githubPath);
            if (codeFile) code = codeFile.content;
          }

          // 2. Fetch question README
          if (folderPath) {
            const readmeFile = await ghGet(`${folderPath}/README.md`);
            if (readmeFile) {
              readme = readmeFile.content;
            } else {
              // Try listing folder to see if README has different casing
              try {
                const itemsRes = await fetch(`https://api.github.com/repos/${leethub_hook}/contents/${folderPath}`, { headers: ghHeaders });
                if (itemsRes.ok) {
                  const items = await itemsRes.json();
                  const rItem = items.find(i => i.name.toLowerCase() === 'readme.md');
                  if (rItem) {
                    const rFile = await ghGet(rItem.path);
                    if (rFile) readme = rFile.content;
                  }
                }
              } catch (e) {}
            }
          }

          const githubUrl = githubPath
            ? `https://github.com/${leethub_hook}/blob/${defaultBranch}/${githubPath}`
            : (folderPath ? `https://github.com/${leethub_hook}/tree/${defaultBranch}/${folderPath}` : '');

          sendResponse({
            success: true,
            problemName,
            code,
            readme,
            githubPath,
            folderPath,
            githubUrl,
            branch: defaultBranch,
            hook: leethub_hook
          });

        // ===== ACTION: striver_move_problem ===================================
        // Moves problem files to a new category/subcategory folder and cleans up old location
        } else if (action === 'striver_move_problem') {
          const problemName = (request.problemName || request.title || '').trim();
          const problemUrl = (request.url || '').trim();
          const oldFolderPath = request.oldFolderPath || '';
          const oldGithubPath = request.oldGithubPath || '';
          const newCategory = (request.newCategory || request.category || '').trim();
          const newSubcategory = (request.newSubcategory || request.subcategory || '').trim();

          if (!problemName) {
            sendResponse({ success: false, error: 'Problem name is required to move.' });
            return;
          }
          if (!newCategory) {
            sendResponse({ success: false, error: 'Category is required to move problem.' });
            return;
          }

          const cleanTitle = stripProblemNumber(problemName) || problemName;
          const safeTitle = sanitizeName(cleanTitle);
          const safeCat = sanitizeName(newCategory);
          const safeSubcat = newSubcategory ? sanitizeName(newSubcategory) : '';

          let newFolderPath = `${STRIVER_ROOT}/${safeCat}`;
          if (safeSubcat) newFolderPath += `/${safeSubcat}`;
          newFolderPath += `/${safeTitle}`;

          if (oldFolderPath === newFolderPath) {
            sendResponse({
              success: true,
              message: `Problem is already in ${newCategory}${newSubcategory ? ' > ' + newSubcategory : ''}.`,
              newFolderPath,
              newGithubPath: oldGithubPath
            });
            return;
          }

          // 1. Move all files from old folder to new folder
          let movedSolutionPath = '';
          let foundFiles = [];

          if (oldFolderPath) {
            try {
              const res = await fetch(`https://api.github.com/repos/${leethub_hook}/contents/${oldFolderPath}`, { headers: ghHeaders });
              if (res.ok) {
                const items = await res.json();
                if (Array.isArray(items)) {
                  foundFiles = items;
                }
              }
            } catch (e) {}
          }

          if (foundFiles.length > 0) {
            for (const file of foundFiles) {
              if (file.type === 'file') {
                const fileData = await ghGet(file.path);
                if (fileData) {
                  const destPath = `${newFolderPath}/${file.name}`;
                  await ghPut(destPath, fileData.content, `Move ${file.name} to ${newCategory}${safeSubcat ? '/' + safeSubcat : ''}`);
                  if (file.name.toLowerCase() !== 'readme.md' && !movedSolutionPath) {
                    movedSolutionPath = destPath;
                  }
                }
              }
            }
            // Delete old files from previous folder
            await ghDeleteFolder(oldFolderPath);
            if (oldGithubPath && !oldGithubPath.startsWith(oldFolderPath)) {
              await ghDelete(oldGithubPath, null, `Clean up old file ${oldGithubPath}`);
            }
          } else if (oldGithubPath) {
            // Standalone code file
            const fileData = await ghGet(oldGithubPath);
            if (fileData) {
              const fileName = oldGithubPath.split('/').pop();
              const destPath = `${newFolderPath}/${fileName}`;
              await ghPut(destPath, fileData.content, `Move ${fileName} to ${newCategory}`);
              movedSolutionPath = destPath;
              await ghDelete(oldGithubPath, fileData.sha, `Remove old file ${oldGithubPath}`);
            }
          }

          if (!movedSolutionPath && oldGithubPath) {
            const fileName = oldGithubPath.split('/').pop();
            movedSolutionPath = `${newFolderPath}/${fileName}`;
          }

          // 2. Update master README.md table
          const masterReadmePath = `${STRIVER_ROOT}/README.md`;
          const masterFile = await ghGet(masterReadmePath);
          if (masterFile) {
            let masterContent = masterFile.content;
            const catLabel = safeSubcat ? `${newCategory}/${newSubcategory}` : newCategory;
            const solutionFileName = movedSolutionPath ? movedSolutionPath.split('/').pop() : `${safeTitle}.cpp`;
            const relativeSolPath = movedSolutionPath
              ? movedSolutionPath.replace(STRIVER_ROOT + '/', '')
              : `${safeCat}/${safeSubcat ? safeSubcat + '/' : ''}${safeTitle}/${solutionFileName}`;
            const newRow = `| [${problemName}](${problemUrl || '#'}) | ${catLabel} | [${solutionFileName}](${relativeSolPath}) |\n`;

            const escapedTitle = problemName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const rowRegex = new RegExp(`\\|\\s*\\[${escapedTitle}\\]\\([^)]*\\)[^\\n]*\\n`, 'g');
            if (masterContent.match(rowRegex)) {
              masterContent = masterContent.replace(rowRegex, newRow);
            } else {
              masterContent += newRow;
            }
            await ghPut(masterReadmePath, masterContent, `Update Master README: move ${problemName} to ${catLabel}`);
          }

          // 3. Update .metadata.json
          const metadata = await getMetadata();
          const searchKey = problemUrl || safeTitle;
          let targetMeta = null;
          let targetKey = null;

          if (metadata.problems[searchKey]) {
            targetMeta = metadata.problems[searchKey];
            targetKey = searchKey;
          } else {
            for (const k in metadata.problems) {
              const p = metadata.problems[k];
              if (p.problemName === problemName || sanitizeName(p.problemName).toLowerCase() === safeTitle.toLowerCase()) {
                targetMeta = p;
                targetKey = k;
                break;
              }
            }
          }

          if (!targetMeta) {
            targetKey = searchKey;
            targetMeta = {
              problemName: problemName,
              url: problemUrl,
              language: 'cpp'
            };
          }

          targetMeta.category = newCategory;
          targetMeta.subcategory = newSubcategory;
          targetMeta.folderPath = newFolderPath;
          if (movedSolutionPath) targetMeta.githubPath = movedSolutionPath;
          targetMeta.lastUpdated = new Date().toISOString();

          metadata.problems[targetKey] = targetMeta;
          await saveMetadata(metadata);

          sendResponse({
            success: true,
            message: `Moved "${problemName}" to ${newCategory}${newSubcategory ? ' > ' + newSubcategory : ''}!`,
            newFolderPath,
            newGithubPath: movedSolutionPath
          });

        } else {
          sendResponse({ success: false, error: `Unknown Striver action: ${action}` });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }
  return true;
}

function isChrome() {
  return typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined';
}

function isFirefox() {
  return typeof browser !== 'undefined' && typeof browser.runtime !== 'undefined';
}
